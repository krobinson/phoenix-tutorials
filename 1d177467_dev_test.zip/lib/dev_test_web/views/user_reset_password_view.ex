defmodule DevTestWeb.UserResetPasswordView do
  use DevTestWeb, :view
end
