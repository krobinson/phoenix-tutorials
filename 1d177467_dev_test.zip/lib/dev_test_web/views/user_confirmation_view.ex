defmodule DevTestWeb.UserConfirmationView do
  use DevTestWeb, :view
end
