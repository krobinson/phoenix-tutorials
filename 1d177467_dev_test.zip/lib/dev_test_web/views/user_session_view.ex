defmodule DevTestWeb.UserSessionView do
  use DevTestWeb, :view
end
