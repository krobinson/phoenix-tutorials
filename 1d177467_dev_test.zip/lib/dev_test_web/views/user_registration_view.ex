defmodule DevTestWeb.UserRegistrationView do
  use DevTestWeb, :view
end
