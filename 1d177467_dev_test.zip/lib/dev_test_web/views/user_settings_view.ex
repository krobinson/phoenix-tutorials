defmodule DevTestWeb.UserSettingsView do
  use DevTestWeb, :view
end
