defmodule DevTestWeb.LayoutView do
  use DevTestWeb, :view
end
