defmodule DevTest.Mailer do
  use Swoosh.Mailer, otp_app: :dev_test
end
